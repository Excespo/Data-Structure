#!/bin/bash

make format
make all
make report
make pack
echo "\nUpdated\n\t- Project saved at 519260910009.zip\n"