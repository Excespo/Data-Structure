#pragma once

#include <cstdio>
#include <cstdlib>

#define ASSERT(cond)

#define ASSERT_EQ(a, b)

#define ASSERT