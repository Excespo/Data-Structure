#include <iostream>

int main () {
    std::cout << "\nWelcome to the DS Final - Route Planning.\nAuthor: LUO Yijie\n";
    return 0;
}